import logo from './logo.svg';
import './App.css';
import CoursePage from './CoursePage';

function App() {
  return (
    <div className="App">
      <CoursePage/>
    </div>
  );
}

export default App;
