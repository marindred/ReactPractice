import React from 'react';
import * as employeeActions from '../Actions/EmployeeAction';
import employeestore from '../Store/EmployeeStore';
class EmployeePage extends React.Component
{
    constructor()
    {
        super();
        this.getEmployees=this.getEmployees.bind(this);
        this.state={
            employees: employeestore.getAllEmployees()
        }
    }
    componentWillMount()
    {
        employeestore.on("change", this.getEmployees);
    }
    getEmployees()
    {
        this.setState({employees: employeestore.getAllEmployees()});
    }
    createEmployee() {employeeActions.createEmployee(this.refs.aname.value, this.refs.adept.value);
    console.log(this.refs.adept.value)}
    render()
    {
        const employees = this.state.employees;
        var li = employees.map((employee)=><li><td>{employee.employeeName}</td><td>{employee.employeeDept}</td></li>);
        return (
            <>
                <table border="3">
                    <tr>
                        <td>Enter Employee Name:</td>
                        <td> <input type="text" ref="aname"/></td>
                        <td>Enter Employee Dept:</td>
                        <td> <input type="text" ref="adept"/></td>
                    </tr>
                    <tr>
                        <td><button onClick={this.createEmployee.bind(this)}>Create Employee</button></td>
                    </tr>
                    <tr>
                        <td> <h2> Employee Details</h2> <ul> {li} </ul> </td> 
                    </tr>
                </table>
            </>
        )
    }
}
export default EmployeePage;