import {EventEmitter} from "events";
import Dispatcher from"../Dispatcher/Dispatcher";
class EmployeeStore extends EventEmitter
{
    constructor()
    {
        super();
        this.employees=[
            {employeeName:'Sachin', employeeDept: 'Dev'},
            {employeeName:"Sevak", employeeDept: 'Dev'},
            {employeeName:"Arjun", employeeDept: 'Dev'},
        ]
    }
    createEmployee(employeeName, employeeDept)
    {
        this.employees.push({employeeName, employeeDept});
        this.emit("change");
    }
    getAllEmployees()
    {
        return this.employees;
    }
    handleActions(actions)
    {
        switch(actions.type)
        {
            case "CREATE_EMPLOYEE":{
                this.createEmployee(actions.employeeName, actions.employeeDept);
                break;
            }
        }
    }
}
const employeestore = new EmployeeStore();
Dispatcher.register(employeestore.handleActions.bind(employeestore));
export default employeestore;