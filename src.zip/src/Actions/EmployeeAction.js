import Dispatcher from"../Dispatcher/Dispatcher";

export function createEmployee(employeeName, employeeDept)
{
    Dispatcher.dispatch({
        type:"CREATE_EMPLOYEE",
        employeeName,
        employeeDept
    });
}