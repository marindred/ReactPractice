import logo from './logo.svg';
import './App.css';
import AuthorPage from './Components/AuthorPage';
import EmployeePage from './Components/EmployeePage';

function App() {
  return (
    <div className="App">
      <EmployeePage/>
    </div>
  );
}

export default App;
